import { join } from 'gy-test-01'
console.log(join(1, 2))

// import _ from 'lodash1'
// export function join(a, b) {
// 	return _.join([a, b, 'c'])
// }

// console.log(join(1, 222233))
