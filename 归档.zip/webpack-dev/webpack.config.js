const htmlWebpackPlugin = require('html-webpack-plugin')
const { CleanWebpackPlugin } = require('clean-webpack-plugin')
const path = require('path')
const { HotModuleReplacementPlugin, ProvidePlugin } = require('webpack')

module.exports = {
	mode: 'production',
	// externals: {
	// 	lodash1: 'lodash',
	// },
	devtool: 'cheap-module-source-map',
	// devtool: 'eval-cheap-module-source-map',
	plugins: [
		new htmlWebpackPlugin({
			template: './index.html',
		}),
		new CleanWebpackPlugin(),
		new HotModuleReplacementPlugin(),
		// new ProvidePlugin({
		// 	_: 'lodash',
		// }),
	],
	entry: {
		main: './src/index.js',
	},
	output: {
		filename: '[name].js',
		path: path.resolve(__dirname, 'dist'),
		library: {
			name: 'library',
			type: 'umd',
		},
	},
	devServer: {
		hot: 'only',
		open: true,
	},
	module: {
		rules: [
			{
				test: /\.css$/,
				use: ['style-loader', 'css-loader'],
			},
			{
				test: /\.js$/,
				exclude: /node_modules/,
				use: {
					loader: 'babel-loader',
					options: {
						presets: [
							[
								'@babel/preset-env',
								{
									// useBuiltIns: false,
									useBuiltIns: 'usage',
									corejs: 3,
								},
							],
						],
						plugins: [
							// [
							// '@babel/plugin-transform-runtime',
							// {
							// 	corejs: {
							// 		version: 3,
							// 		proposals: true,
							// 	},
							// },
							// ],
						],
					},
				},
			},
		],
	},
}
