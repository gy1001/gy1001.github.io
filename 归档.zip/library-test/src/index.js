import _ from 'lodash1'
export function join(a, b) {
	return _.join([a, b, 'c'], '$')
}
console.log()
