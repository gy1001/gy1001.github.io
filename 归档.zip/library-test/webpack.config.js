const path = require('path')
const htmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
	mode: 'development',
	entry: {
		main: './src/index.js',
	},
	externals: {
		lodash1: 'lodash',
	},
	output: {
		filename: '[name].js',
		path: path.resolve(__dirname, 'dist'),
		library: {
			name: 'gyTest01',
			type: 'umd',
		},
	},
	plugins: [
		new htmlWebpackPlugin({
			template: './src/index.html',
		}),
	],
}
